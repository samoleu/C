/*

assinatura: void* memset( const void* fonte, int caractere, size_t num)

O comando memset() é uma função da biblioteca <string.h> 
que é usada para inicializar um bloco de memória com um 
determinado valor, como se fosse um calloc,
mas voce pode delimitar os valores a serem alocados.


ptr: um ponteiro para o bloco de memória que será inicializado.
value: o valor que será atribuído a cada byte do bloco de memória.
num: o número de bytes a serem preenchidos com o valor especificado.

*/

#include <stdio.h>
#include <string.h>

int main() {
    int array[10];
    memset(array, 5, sizeof(array));
    // O comando acima preenche o array com cincos

    return 0;
}