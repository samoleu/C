/*

assinatura: void abort (void)

interrompe e aborta a execução do programa no ponto em que abort() é chamada.

essa função não recebe nenhum parâmetro
e não retorna nada, é uma função void 

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char* str = malloc(10); 

    if (str == NULL) {
        printf("--ERRO--\n");
        abort(); // aborta a execução do programa em caso de falha na alocação
    }

    strcpy(str, "Hello"); 
    printf("%s\n", str); 
  
    free(str); 
    return 0;
}