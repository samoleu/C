#include <stdlib.h>
#include <stdio.h>

/*
num: quantidade de elementos
tam: tamanho em bytes dos elementos
*/

void *calloc (size_t num, size_t tam);

/*
    A função calloc aloca na memória heap
e inicializa todos os bytes alocados com zero.
    O calloc retorna um ponteiro do tipo void para o espaço alocado na memória heap caso bem sucedido, senão
retorna NULL
*/

int main( void )
{
   int *a;
    /*cria o calloc com tamanho de 5 ints*/
   a = (int *)calloc(5, sizeof(int));
   /*verifica se calloc foi bem sucedida*/
   if( a == NULL )
      printf( "não foi possivel fazer o calloc\n" );

    int i=0;
    while (i<5)
    {
        a[i] = 5;
        i++;
    }

    printf("%d", a[3]);
    
   free(a);
}