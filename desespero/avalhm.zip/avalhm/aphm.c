#include "tadlista.h"
#include "tadhm.h"
#include <stdio.h>
#include <string.h>


t_hashmap carregadi(char *nomearq) {

    FILE *arquivo = fopen(nomearq, "r");
    if (arquivo == NULL) {
        printf("deu merda");
        return NULL; 
    }

    t_hashmap dicionario = cria_hm_tam(256);

    char linha[64];
    int i = 1;

    while (!feof(arquivo)) {

        fgets(linha,64,arquivo);

        char* chave = (char*)malloc(sizeof(char)*32);
        char* valor = (char*)malloc(sizeof(char)*32);
        
//-------------------------


        char *token;
        char *rest = linha;

        token = strtok_r(rest, ",", &rest);
        while (token != NULL) {
        printf("%s\n", token);
        token = strtok_r(rest, ",", &rest);
        }


//------------------------
        //strcpy(chave, strtok_r(linha,","));
        //strcpy(valor, strtok_r(NULL,","));
        
        dicionario = addDado(dicionario, chave, valor);
        printf("%d key: %s value: %s", i, chave, valor);
        
        i++;
    }
    
    printf("%d key: %s value: %s", i, "maos", (char*)getDado(dicionario,"maos"));
    
    fclose(arquivo);
    return dicionario;
}

// t_hashmap invertedi(t_hashmap dict){
//     for(int i = 0; i< lenLista(dict); i++){
//     }
//  return dicionario;
// }

int main() {

    t_hashmap dicionario = carregadi("di-pt-fr.txt");

    char* palavra = (char*)getDado(dicionario,"maos");
    printf("%s", palavra);
    
    //t_hashmap dictInverted = invertedi(dicionario);
    
    return 0;
}