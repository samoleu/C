#include <stdlib.h>
#include <stdio.h>

/*
vetordin: vetor alocado na memória heap
tam: tamanho em bytes dos elementos
*/
// void *realloc (void *vetordin, size_t tam);

/*A funçao realloc modifica o tamanho da memória previamente alocada em vetordin para aquele em num.
O valor de num pode ser maior ou menor que o original.

Um ponteiro para o bloco de memoria é devolvido pois, pode ser necessário mover o bloco para aumentar seu tamanho. 
Se isso ocorrer, o conteúdo do bloco antigo é copiado no novo bloco, e nenhuma informação é perdida. 

Se vetordin for nulo, aloca size bytes e devolve um ponteiro;
Se size é zero, a memória apontada por vetordin é liberada. 
Se não houver memória suficiente para a alocação,
um ponteiro nulo é devolvido e o bloco original é deixado inalterado. */

int main()
{
    int *vetordin = (int *)malloc(5*sizeof(int));
    if( vetordin == NULL )
        printf( "não foi possivel fazer o calloc\n" );    
    
    realloc (vetordin, 10);
    int i = 0;
    while (i<10)
    {
        vetordin[i] = 5;
        i++;
    }

    printf("%d", vetordin[8]);
    
    
    free(vetordin);
    return 0;
}
