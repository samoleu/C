/*


assinatura: int system (const char *);


A função system() permite que você execute comandos do sistema, como chamar outros programas, executar scripts e assim por diante.

como entrada ela recebe uma linha de comando em string

e retorna um numero inteiro caso consiga fazer a requisição ao sO
  
  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char* command = malloc(100); 

    sprintf(command, "dir \"bdveiculos.txt\"");

    // Executa o comando usando a função system
    int result = system(command);

    if (result == -1) {
        printf("Erro ao executar o comando.\n");
    } else {
        printf("Comando executado com sucesso.\n");
    }

    free(command);
    return 0;
}