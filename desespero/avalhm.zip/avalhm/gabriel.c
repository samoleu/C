#include "tadhm.h"
#include "tadlista.h"

int calcula_hashing(char* chave, int tamanho_tabela) {
    int soma = 0;
    for (int i=0; i< strlen(chave); i++) {
        soma = (soma * i) + (chave[i] * (i+1));
    }
    return soma % tamanho_tabela;
}
t_hashmap cria_hm() {
    t_hashmap hashmap = malloc(sizeof(struct cabec_hm));
    hashmap->tam_vet_lista = TAM_VET_ARMAZENAM;
    hashmap->vet_lista = malloc(sizeof(Lista)*TAM_VET_ARMAZENAM);
    for (int i=0; i<TAM_VET_ARMAZENAM; i++) {
        hashmap->vet_lista[i] = NULL;
    }
    return hashmap;
}
t_hashmap cria_hm_tam(int quant_dados) {

    long tam_vet_armazen = (long) (quant_dados / FATOR_DE_CARGA);
    t_hashmap hashmap = malloc(sizeof(struct cabec_hm));
    hashmap->tam_vet_lista = tam_vet_armazen;
    hashmap->vet_lista = malloc(sizeof(Lista) * tam_vet_armazen);
    for (int i = 0; i < tam_vet_armazen; i++) {
        hashmap->vet_lista[i] = NULL;
    }

    return hashmap;
}
t_item getItem(t_hashmap hashmap, char *key){
    long hash = calcula_hashing(key, hashmap->tam_vet_lista);

    if(hashmap->vet_lista[hash] == NULL){ return NULL; }
    else {
        Lista lista = hashmap->vet_lista[hash];
        t_item item_da_lista = NULL;
        int i = 0;
        for (i=0;i<lenLista(lista); i++){
            item_da_lista = dadoLista(lista, i);
            if(strcmp(item_da_lista->key, key) == 0){
                break;
            }
        }
        if(i<lenLista(lista)){
            return item_da_lista;
        }//Fim do if
        else{
            return NULL;
        }
    }
}
t_hashmap addDado(t_hashmap hashmap, char *key, t_dado dado) {
    long loc = calcula_hashing(key, hashmap->tam_vet_lista);
    t_item item = getItem(hashmap, key);
    if (item == NULL){
        item = malloc(sizeof(struct tipo_item));
        item->key = key;
        item->valor = dado;
        if(hashmap->vet_lista[loc] == NULL) {
            hashmap->vet_lista[loc] = criaLista();
        }
        appendLista(hashmap->vet_lista[loc],item);
    }
    else{
        item->valor = dado;
    }
    return hashmap;
}

t_dado getDado(t_hashmap hashmap,char *key) {
    t_item item = getItem(hashmap, key);
    if (item == NULL){
        return NULL;
    }
    else{
        return item->valor;
    }
}

Lista keys(t_hashmap hashmap) {
    Lista lista = criaLista();
    for (int i = 0; i < hashmap->tam_vet_lista; i++){
        if(hashmap->vet_lista[i] != NULL){
            for(int j = 0; j < lenLista(hashmap->vet_lista[i]); j++){
                t_item item = dadoLista(hashmap->vet_lista[i], j);
                appendLista(lista, item->key);
            }
        }
    }
    return lista;
}